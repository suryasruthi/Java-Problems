import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashMap;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;

public class MainPart2 {
    /*
    * Question 2:
    * - In this question you will use the Data.users array that includes
    * a list of users. Formatted as : firstname,lastname,age,email,gender,city,state
    * - Create a User class that should parse all the parameters for each user.
    * - The goal is to count the number of users living each state.
    * - Print out the list of State, Count order in ascending order by count.
    * */

    public static void main(String[] args) {

        
    	ArrayList<User> userlist =new ArrayList<User>();
        //example on how to access the Data.users array.
        for (String str : Data.users) {
            User user=new User(str);
            userlist.add(user);
        }

		HashMap<String, Integer> frequencyMap = new HashMap<String,Integer>();
		for (User s: userlist) {
			Integer count = frequencyMap.get(s.state);
			if (count == null)
				frequencyMap.put(s.state, 1);
			else  {
				frequencyMap.put(s.state, count + 1);
			}

		}

		for (Map.Entry<String, Integer> entry : frequencyMap.entrySet()) {
			System.out.println(entry.getKey() + ": " + entry.getValue());
		}
        
    }
        
    }




/*

List<Entry<String, Integer>> list = new LinkedList<Entry<String, Integer>>(userMap.entrySet());
Collections.sort(list, new Comparator<Entry<String, Integer>>(){
	@Override
	public int compare(Entry<String, Integer> o1, Entry<String, Integer> o2) {
		// TODO Auto-generated method stub
		return o1.getValue().compareTo(o2.getValue());
	}
});
for(Entry<String, Integer> mapping : list){
	System.out.println(mapping.getKey() +" "+ mapping.getValue()); 
	}

*/

