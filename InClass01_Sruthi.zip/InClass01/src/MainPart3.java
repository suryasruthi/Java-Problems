import java.util.ArrayList;
import java.util.HashSet;

public class MainPart3 {
    /*
    * Question 3:
    * - In this question you will use the Data.users and Data.otherUsers array that includes
    * a list of users. Formatted as : firstname,lastname,age,email,gender,city,state
    * - Create a User class that should parse all the parameters for each user.
    * - The goal is to print out the users that are exist in both the Data.users and Data.otherUsers.
    * Two users are equal if all their attributes are equal.
    * - Print out the list of users which exist in both Data.users and Data.otherUsers.
    * */

    public static void main(String[] args) {

    	
    	
    	ArrayList<User> userList =new ArrayList<>();
    	ArrayList<User> otheruserList=new ArrayList<>();
    	ArrayList<User> commonList=new ArrayList<>();
    	
    	
    	for(String str : Data.users) {
    	User user=new User(str);
    	userList.add(user);
    	}
    	
    	for(String str : Data.otherUsers) {
    		User user=new User(str);
    		otheruserList.add(user);
    	}
    	
    	for(User temp :userList) {
    		if (otheruserList.contains(temp)) {
    			commonList.add(temp);
    		}
    	}
    	
    	System.out.println(commonList);
    	
    	
    	/*
    
    	HashSet<User> list1=new HashSet<User>();
    	HashSet<User> list2=new HashSet<User>();

        for (String str : Data.users) {
        	User user=new User(str);
        	list1.add(user);
        }
        
        for (String str : Data.otherUsers) {
        	User usr=new User(str);
        	if(list1.contains(usr)){
        		list2.add(new User(str));
        		System.out.println(usr);
        	}
        }
        
        */
    }
}